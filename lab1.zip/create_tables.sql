drop database if exists CustomerComplaints;
create database CustomerComplaints;
use CustomerComplaints; 

Create Table Product(
	product_id integer primary key,
	product_type varchar(50) not null,
	sub_product varchar(50) 
);

Create Table Person(
	email varchar(100) primary key,
	first_name varchar(50) not null,
	last_name varchar(50) not null,
	gender enum('male', 'female')
);

Create Table Complaint (
	complaint_id integer primary key,
	date_received date not null,
	issue varchar(200) not null,
	timely_response enum('Yes', 'No') not null,
	date_sent_to_company date not null,
	email varchar(100) not null, 
	product_id integer not null,
	foreign key (email) references Person(email),
	foreign key (product_id) references Product(product_id)
);

Create Table Company(
	name varchar(100) primary key,
	state char(2) not null, 
	zipcode integer not null 
);

Create Table Company_Product(
	product_id integer,
	name varchar(100),
	primary key (product_id, name),
	foreign key (product_id) references Product(product_id),
	foreign key (name) references Company(name)
);
